﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MorseLight : MonoBehaviour
{
    public SpriteRenderer sr;

    public string message;
    public float DashTime;
    public float DotTime;
    public float SpaceTime;
    public float WaitTime;

    public string state = "Wait";
    public int character;
    public float currenttime;

    void Update()
    {
        if (state == "Wait")
        {
            sr.enabled = false;
            currenttime = currenttime + Time.deltaTime;
            if (currenttime >= WaitTime)
            {
                currenttime = 0;
                character = character + 1;
                if (character > message.Length - 1)
                {
                    character = 0;
                }
                state = "Light";
            }
        } else
        {
            sr.enabled = true;
            currenttime = currenttime + Time.deltaTime;
            if (message[character].ToString() == ".")
            {
                if (currenttime >= DotTime)
                {
                    currenttime = 0;
                    state = "Wait";
                }
            } else if (message[character].ToString() == "-")
            {
                if (currenttime >= DashTime)
                {
                    currenttime = 0;
                    state = "Wait";
                }
            } else
            {
                sr.enabled = false;
                if (currenttime >= SpaceTime)
                {
                    currenttime = 0;
                    state = "Wait";
                }
            }
        }
    }
}
