﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public float PortalEnergy;
    public float MaxPortalEnergy = 100;
    public float minPortalSize;
    public float maxPortalSize;
    public GameObject Portal;
    public AudioSource Music;
    public float time;
    public string timestring;
    public Text timetext;
    public Text timetextshadow;
    public Player plr;
    public string state = "Game";
    public Vector3 firedsize;
    public GameObject clone;
    public ParticleSystem rubble;
    public GameObject alarm1;
    public GameObject alarm2;
    public GameObject camera;

    private float timetilnextls = 3f;
    private float nextls = 0f;
    public GameObject ls;
    private GameObject currentls;

    private float timetilnextrs = 3f;
    private float nextrs = 0f;
    public GameObject rs;
    private GameObject currentrs;

    private float timetilnextlaz = 7f;
    private float nextlaz = 0f;
    public float currentwall = 0f;
    private float currentlaz = 0f;
    public GameObject wall;
    public GameObject laz;
    public Sprite laz1;
    public Sprite laz2;
    public Sprite lazDeactivated;

    public GameObject firedText;

    public float wait;

    public string tutostate;
    public List<string> text1;
    public List<string> text2;
    public List<string> text3;
    public List<string> text4;
    public List<string> text5;
    public int textprogress = 0;
    public GameObject textbox;
    public GameObject textboxbox;

    public void Start()
    {
        SaveFile save = SaveSystem.LoadSaveFile();
        plr.music = save.music;
        plr.soundeffects = save.soundeffects;
        plr.highscore = save.highscore;
        firedsize = firedText.transform.localScale;
    }

    public void ManageLeftScientists()
    {
        nextls += Time.deltaTime;
        if (nextls >= timetilnextls)
        {
            if (currentls == null)
            {
                currentls = Instantiate(ls);
                currentls.SetActive(true);
            }
            timetilnextls = 5f + Random.Range(0.0f, 10.0f);
            nextls = 0f;
        }
    }

    public void ManageRightScientists()
    {
        nextrs += Time.deltaTime;
        if (nextrs >= timetilnextrs)
        {
            if (currentrs == null)
            {
                currentrs = Instantiate(rs);
                currentrs.SetActive(true);
            }
            timetilnextrs = 5f + Random.Range(0.0f, 10.0f);
            nextrs = 0f;
        }
    }

    public void ManageLasers()
    {
        wall.transform.rotation = Quaternion.Euler(0, 0, currentwall);
        laz.transform.rotation = Quaternion.Euler(0, 0, currentlaz);
        nextlaz += Time.deltaTime;
        if (currentlaz == currentwall)
        {
            laz.GetComponent<SpriteRenderer>().sprite = laz2;
        } else
        {
            laz.GetComponent<SpriteRenderer>().sprite = laz1;
            PortalEnergy = PortalEnergy - 0.2f;
            if (PortalEnergy < 0)
            {
                PortalEnergy = 0;
            }
        }
        if (nextlaz >= timetilnextlaz)
        {
            currentlaz = Random.Range(-1, 2) * 90f;
            timetilnextlaz = 12f + Random.Range(0.0f, 24.0f);
            nextlaz = 0f;
        }
    }

    void Update()
    {
        if (state == "Game")
        {
            Portal.transform.localScale = new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100));
            Music.pitch = 1f + (1f - PortalEnergy / 100);
            ManageLeftScientists();
            ManageRightScientists();
            ManageLasers();
            time = time + Time.deltaTime;
            int hours = Mathf.FloorToInt(time / 3600);
            int minutes = Mathf.FloorToInt((time - hours * 3600) / 60);
            int seconds = Mathf.FloorToInt(time % 60);
            string timestring = string.Format("Time: " + hours.ToString() + ":{0:00}:{1:00}", minutes, seconds);
            timetext.text = timestring;
            timetextshadow.text = timestring;
            if (PortalEnergy == 0)
            {
                firedsize = firedText.transform.localScale;
                firedText.transform.localScale = new Vector3(0, 0, 0);
                state = "Fired";
            }
        }
        else if (state == "Fired")
        {
            plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
            Music.Stop();
            camera.GetComponent<CameraScript>().dostuff = false;
            rubble.Stop();
            if (rs != null)
            {
                Destroy(rs);
            }
            if (ls != null)
            {
                Destroy(ls);
            }
            laz.GetComponent<SpriteRenderer>().sprite = lazDeactivated;
            wait += Time.deltaTime;
            firedText.SetActive(true);
            firedText.transform.localScale = Vector3.Lerp(firedText.transform.localScale, firedsize, 0.125f);
            Portal.transform.localScale = Vector3.Lerp(Portal.transform.localScale, new Vector3(0, 0, 0), 0.125f);
            if (wait > 5f)
            {
                if (time > plr.highscore)
                {
                    plr.highscore = time;
                    SaveSystem.Save(plr);
                }
                SceneManager.LoadScene("Menu", LoadSceneMode.Single);
            }
        }
        else if (state == "Game Start")
        {
            Portal.transform.localScale = Vector2.Lerp(Portal.transform.localScale, new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100)), 0.125f);
            laz.GetComponent<SpriteRenderer>().sprite = lazDeactivated;
            if (clone == null)
            {
                clone = Instantiate(firedText);
                clone.SetActive(true);
            }
            int hours = Mathf.FloorToInt(time / 3600);
            int minutes = Mathf.FloorToInt((time - hours * 3600) / 60);
            int seconds = Mathf.FloorToInt(time % 60);
            string timestring = string.Format("Time: " + hours.ToString() + ":{0:00}:{1:00}", minutes, seconds);
            timetext.text = timestring;
            timetextshadow.text = timestring;
            plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
            wait += Time.deltaTime;
            firedText.transform.localScale = new Vector3(0, 0, 0);
            if (wait > 4f)
            {
                Destroy(clone);
                firedText.transform.localScale = firedsize;
                state = "Game";
                wait = 0;
                plr.gameObject.GetComponent<PlayerMovement>().canmove = true;
            }
            else if (wait > 3f)
            {
                rubble.Play();
                if (clone.GetComponent<TextMesh>().text != "GO!")
                {
                    camera.GetComponent<CameraScript>().dostuff = true;
                    clone.GetComponent<TextMesh>().text = "GO!";
                    clone.transform.Find("FIRED SHADOW").GetComponent<TextMesh>().text = "GO!";
                    clone.transform.localScale = new Vector3(0, 0, 0);
                }
                clone.transform.localScale = Vector3.Lerp(clone.transform.localScale, firedsize, 0.125f);
            }
            else if (wait > 2f)
            {
                if (clone.GetComponent<TextMesh>().text != "1")
                {
                    clone.GetComponent<TextMesh>().text = "1";
                    alarm1.SetActive(true);
                    alarm2.SetActive(true);
                    clone.transform.Find("FIRED SHADOW").GetComponent<TextMesh>().text = "1";
                    clone.transform.localScale = new Vector3(0, 0, 0);
                }
                clone.transform.localScale = Vector3.Lerp(clone.transform.localScale, firedsize, 0.125f);
            }
            else if (wait > 1f)
            {
                if (clone.GetComponent<TextMesh>().text != "2")
                {
                    clone.GetComponent<TextMesh>().text = "2";
                    clone.transform.Find("FIRED SHADOW").GetComponent<TextMesh>().text = "2";
                    clone.transform.localScale = new Vector3(0, 0, 0);
                }
                clone.transform.localScale = Vector3.Lerp(clone.transform.localScale, firedsize, 0.125f);
            }
            else
            {
                if (clone.GetComponent<TextMesh>().text != "3")
                {
                    clone.GetComponent<TextMesh>().text = "3";
                    clone.transform.Find("FIRED SHADOW").GetComponent<TextMesh>().text = "3";
                    clone.transform.localScale = new Vector3(0, 0, 0);
                }
                clone.transform.localScale = Vector3.Lerp(clone.transform.localScale, firedsize, 0.125f);
            }
        }
        else if (state == "Tutorial")
        {
            if (PortalEnergy == 0)
            {
                firedsize = firedText.transform.localScale;
                firedText.transform.localScale = new Vector3(0, 0, 0);
                state = "Fired";
            }
            if (tutostate == "hello")
            {
                laz.GetComponent<SpriteRenderer>().sprite = lazDeactivated;
                plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
                text1[textprogress] = text1[textprogress].Replace("NEWLINE", "\n");
                textbox.GetComponent<TextMesh>().text = text1[textprogress];
                if (text1[textprogress].StartsWith(":"))
                {
                    textbox.GetComponent<TextMesh>().text = text1[textprogress].Substring(1, text1[textprogress].Length - 1); ;
                    textbox.GetComponent<TextMesh>().color = new Color(1, 1, 1, 1);
                }
                else
                {
                    textbox.GetComponent<TextMesh>().color = new Color(4f / 255f, 128f / 255f, 0f, 1f);
                }
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    textprogress += 1;
                    if (textprogress == text1.Count)
                    {
                        tutostate = "OpenPortal";
                        textboxbox.SetActive(false);
                        wait = 0;
                    }
                }
            }
            else if (tutostate == "OpenPortal")
            {
                wait += Time.deltaTime;
                Portal.transform.localScale = Vector2.Lerp(Portal.transform.localScale, new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100)), 0.125f);
                if (wait >= 5f)
                {
                    alarm1.SetActive(true);
                    alarm2.SetActive(true);
                    rubble.Play();
                    tutostate = "wrong";
                    textprogress = 0;
                    wait = 0f;
                }
                else if (wait >= 3f)
                {
                    camera.GetComponent<CameraScript>().dostuff = true;
                }
            }
            else if (tutostate == "wrong")
            {
                textboxbox.SetActive(true);
                text2[textprogress] = text2[textprogress].Replace("NEWLINE", "\n");
                textbox.GetComponent<TextMesh>().text = text2[textprogress];
                if (text2[textprogress].StartsWith(":"))
                {
                    textbox.GetComponent<TextMesh>().text = text2[textprogress].Substring(1, text2[textprogress].Length - 1); ;
                    textbox.GetComponent<TextMesh>().color = new Color(1, 1, 1, 1);
                }
                else
                {
                    textbox.GetComponent<TextMesh>().color = new Color(4f / 255f, 128f / 255f, 0f, 1f);
                }
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    textprogress += 1;
                    if (textprogress == text2.Count)
                    {
                        tutostate = "slapscientists";
                        textboxbox.SetActive(false);
                        wait = 0;
                        if (currentrs == null)
                        {
                            currentrs = Instantiate(rs);
                            currentrs.SetActive(true);
                        }
                        if (currentls == null)
                        {
                            currentls = Instantiate(ls);
                            currentls.SetActive(true);
                        }
                    }
                }
            }
            else if (tutostate == "slapscientists")
            {
                Portal.transform.localScale = new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100));
                plr.gameObject.GetComponent<PlayerMovement>().canmove = true;
                if (currentrs == null && currentls == null)
                {
                    textprogress = 0;
                    tutostate = "warnlasers";
                }
            }
            else if (tutostate == "warnlasers")
            {
                plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
                textboxbox.SetActive(true);
                text3[textprogress] = text3[textprogress].Replace("NEWLINE", "\n");
                textbox.GetComponent<TextMesh>().text = text3[textprogress];
                if (text3[textprogress].StartsWith(":"))
                {
                    textbox.GetComponent<TextMesh>().text = text3[textprogress].Substring(1, text3[textprogress].Length - 1); ;
                    textbox.GetComponent<TextMesh>().color = new Color(1, 1, 1, 1);
                }
                else
                {
                    textbox.GetComponent<TextMesh>().color = new Color(4f / 255f, 128f / 255f, 0f, 1f);
                }
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    textprogress += 1;
                    if (textprogress == text3.Count)
                    {
                        textboxbox.SetActive(false);
                        tutostate = "stoplaser";
                        currentlaz = currentwall + 90f;
                        if (currentlaz == -180f)
                        {
                            currentlaz = 180f;
                        }
                    }
                }
            }
            else if (tutostate == "stoplaser")
            {
                plr.gameObject.GetComponent<PlayerMovement>().canmove = true;
                Portal.transform.localScale = new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100));
                wall.transform.rotation = Quaternion.Euler(0, 0, currentwall);
                laz.transform.rotation = Quaternion.Euler(0, 0, currentlaz);
                if (currentlaz == currentwall)
                {
                    laz.GetComponent<SpriteRenderer>().sprite = laz2;
                    tutostate = "alimentationtext";
                    textprogress = 0;
                }
                else
                {
                    laz.GetComponent<SpriteRenderer>().sprite = laz1;
                    PortalEnergy = PortalEnergy - 0.2f;
                    if (PortalEnergy < 0)
                    {
                        PortalEnergy = 0;
                    }
                }
            }
            else if (tutostate == "alimentationtext")
            {
                plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
                textboxbox.SetActive(true);
                text4[textprogress] = text4[textprogress].Replace("NEWLINE", "\n");
                textbox.GetComponent<TextMesh>().text = text4[textprogress];
                if (text4[textprogress].StartsWith(":"))
                {
                    textbox.GetComponent<TextMesh>().text = text4[textprogress].Substring(1, text4[textprogress].Length - 1); ;
                    textbox.GetComponent<TextMesh>().color = new Color(1, 1, 1, 1);
                }
                else
                {
                    textbox.GetComponent<TextMesh>().color = new Color(4f / 255f, 128f / 255f, 0f, 1f);
                }
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    textprogress += 1;
                    if (textprogress == text4.Count)
                    {
                        textboxbox.SetActive(false);
                        tutostate = "alim";
                        currentlaz = -90f;
                    }
                }
            }
            else if (tutostate == "alim")
            {
                plr.gameObject.GetComponent<PlayerMovement>().canmove = true;
                Portal.transform.localScale = new Vector2(minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100), minPortalSize + (maxPortalSize - minPortalSize) * (PortalEnergy / 100));
                if (PortalEnergy == MaxPortalEnergy)
                {
                    tutostate = "close";
                    textprogress = 0;
                }
            }
            else if (tutostate == "close")
            {
                plr.gameObject.GetComponent<PlayerMovement>().canmove = false;
                textboxbox.SetActive(true);
                text5[textprogress] = text5[textprogress].Replace("NEWLINE", "\n");
                textbox.GetComponent<TextMesh>().text = text5[textprogress];
                if (text5[textprogress].StartsWith(":"))
                {
                    textbox.GetComponent<TextMesh>().text = text5[textprogress].Substring(1, text5[textprogress].Length - 1); ;
                    textbox.GetComponent<TextMesh>().color = new Color(1, 1, 1, 1);
                }
                else
                {
                    textbox.GetComponent<TextMesh>().color = new Color(4f / 255f, 128f / 255f, 0f, 1f);
                }
                if (Input.GetKeyDown(KeyCode.Space))
                {
                    textprogress += 1;
                    if (textprogress == text5.Count)
                    {
                        SceneManager.LoadScene("Menu", LoadSceneMode.Single);
                    }
                }
            }
        }
    }
}
