﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkspeed;
    public float healpower;
    public bool isslapping = false;
    public bool canslap = true;
    public bool issitting;
    public GameObject chair;
    public GameObject slapPivot;
    public GameObject slap;
    public bool canmove = true;
    public GameObject slapairsound;
    public GameObject typesound;

    public Collider2D plrCollider;
    public Collider2D slapCollider;

    public GameManager gm;
    public Rigidbody2D rb;
    public Animator anim;

    void Update()
    {
        if (canmove == true)
        {
            if (issitting == true)
            {
                slap.GetComponent<Animator>().SetBool("Slap", false);
                anim.SetBool("IsWalking", false);
                gameObject.transform.position = chair.transform.GetChild(0).transform.position;
                if (chair.name == "AlimentationChair" && Input.GetKeyDown(KeyCode.Space))
                {
                    GameObject sound = Instantiate(typesound);
                    sound.SetActive(true);
                    gm.PortalEnergy += healpower;
                    if (gm.PortalEnergy > gm.MaxPortalEnergy)
                    {
                        gm.PortalEnergy = gm.MaxPortalEnergy;
                    }
                }
                if (chair.name == "DefenseChair")
                {
                    if (Input.GetKeyDown(KeyCode.UpArrow))
                    {
                        GameObject sound = Instantiate(typesound);
                        sound.SetActive(true);
                        gm.currentwall = 0f;
                    }
                    if (Input.GetKeyDown(KeyCode.DownArrow))
                    {
                        GameObject sound = Instantiate(typesound);
                        sound.SetActive(true);
                        gm.currentwall = 180f;
                    }
                    if (Input.GetKeyDown(KeyCode.LeftArrow))
                    {
                        GameObject sound = Instantiate(typesound);
                        sound.SetActive(true);
                        gm.currentwall = 90f;
                    }
                    if (Input.GetKeyDown(KeyCode.RightArrow))
                    {
                        GameObject sound = Instantiate(typesound);
                        sound.SetActive(true);
                        gm.currentwall = -90f;
                    }
                }
                if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.A))
                {
                    issitting = false;
                }
            }
            else
            {
                slap.GetComponent<BoxCollider2D>().enabled = false;
                slap.GetComponent<Animator>().SetBool("Slap", false);
                isslapping = false;
                rb.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * walkspeed, Input.GetAxisRaw("Vertical") * walkspeed);
                if (rb.velocity == new Vector2(0f, 0f))
                {
                    anim.SetBool("IsWalking", false);
                }
                else
                {
                    anim.SetBool("IsWalking", true);
                }
                if (Input.GetKeyDown(KeyCode.Space) && isslapping == false)
                {
                    GameObject sound = Instantiate(slapairsound);
                    sound.SetActive(true);
                    if (gameObject.transform.position.x > 0)
                    {
                        slap.GetComponent<SpriteRenderer>().flipY = true;
                        slapPivot.transform.rotation = Quaternion.Euler(0, 0, 180);
                    }
                    else
                    {
                        slap.GetComponent<SpriteRenderer>().flipY = false;
                        slapPivot.transform.rotation = Quaternion.Euler(0, 0, 0);
                    }
                    slap.GetComponent<BoxCollider2D>().enabled = true;
                    isslapping = true;
                    slap.GetComponent<Animator>().SetBool("Slap", true);
                }
            }
        } else
        {
            rb.velocity = new Vector3(0, 0, 0);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.gameObject.CompareTag("Chair") && plrCollider.IsTouching(collision)) 
        {
            chair = collision.gameObject;
            issitting = true;
        }
    }
}
