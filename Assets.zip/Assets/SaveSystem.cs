﻿using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem
{
    public static void Save(Player player)
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/player.ItsGonnaWork";
        FileStream stream = new FileStream(path, FileMode.Create);

        SaveFile save = new SaveFile(player);
        formatter.Serialize(stream, save);
        stream.Close();
    }

    public static SaveFile LoadSaveFile()
    {
        string path = Application.persistentDataPath + "/player.ItsGonnaWork";
        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path,FileMode.Open);

            SaveFile save = formatter.Deserialize(stream) as SaveFile;

            stream.Close();

            return save;
        } else
        {
            Debug.LogError("lol save file not found XD");
            return null;
        }
    }
}
