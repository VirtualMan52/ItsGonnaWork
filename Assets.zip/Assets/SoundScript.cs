﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundScript : MonoBehaviour
{
    public Player plr;
    public bool loop;
    public float maxvolume = 1f;

    void Update()
    {
        if (plr.soundeffects == true)
        {
            gameObject.GetComponent<AudioSource>().volume = maxvolume;
        }
        else
        {
            gameObject.GetComponent<AudioSource>().volume = 0f;
        }
        if (gameObject.GetComponent<AudioSource>().isPlaying == false)
        {
            if (loop == true)
            {
                gameObject.GetComponent<AudioSource>().Play();
            } else
            {
                Destroy(gameObject);
            }
        }
    }
}
