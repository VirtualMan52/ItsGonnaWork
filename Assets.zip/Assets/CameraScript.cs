﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    public Rigidbody2D rb;
    public bool dostuff;
    void Update()
    {
        if (dostuff == true)
        {
            rb.velocity += (new Vector2(Random.Range(-0.05f, 0.05f), Random.Range(-0.05f, 0.05f)));
        }
        gameObject.transform.position = Vector3.Lerp(gameObject.transform.position,new Vector3(0,0,-10),0.5f);
    }
}
