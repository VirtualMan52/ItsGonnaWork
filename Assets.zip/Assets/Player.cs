﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public bool music;
    public bool soundeffects;
    public float highscore;
}
