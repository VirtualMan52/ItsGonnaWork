﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeftScientist : MonoBehaviour
{
    public float walkspeed = 3f;
    public float slapspeed = 5f;
    public float slaprotspeed = -280f;
    public string state = "Walking";
    public float damage;
    public float distance;
    public GameObject slapsound;

    public GameManager gm;
    public Rigidbody2D rb;

    void Start()
    {
        damage = Random.Range(0.03f, 0.10f);
    }

    void Update()
    {
        if (state == "Walking")
        {
            rb.velocity = new Vector2(walkspeed,0);
            if (gameObject.transform.position.x >= distance)
            {
                state = "Hurting";
            }
        } else if (state == "Hurting") {
            gameObject.transform.Find("TypeNoise").gameObject.SetActive(true);
            gm.PortalEnergy -= damage;
            if (gm.PortalEnergy < 0)
            {
                gm.PortalEnergy = 0;
            }
            gameObject.transform.position = new Vector3(distance, gameObject.transform.position.y,0);
        } else if (state == "Slapped") {
            gameObject.transform.Find("TypeNoise").gameObject.SetActive(false);
            rb.velocity = new Vector2(slapspeed, 0);
            rb.angularVelocity = slaprotspeed;
            if (transform.position.x > 0)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Slap"))
        {
            GameObject sound = Instantiate(slapsound);
            sound.SetActive(true);
            state = "Slapped";
        }
    }
}
