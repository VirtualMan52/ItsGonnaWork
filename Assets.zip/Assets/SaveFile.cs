﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveFile
{
    public bool music;
    public bool soundeffects;
    public float highscore;

    public SaveFile(Player player)
    {
       music = player.music;
       soundeffects = player.soundeffects;
       highscore = player.highscore;
    }
}
