﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class MenuScript : MonoBehaviour
{
    public List<GameObject> selections;
    public List<GameObject> options;
    public List<GameObject> currentselections;
    public int selected;
    public GameObject highscoredisplay;

    public GameObject selectedsound;
    public GameObject changesound;

    public Player plr;

    void Start()
    {
        string path = Application.persistentDataPath + "/player.ItsGonnaWork";
        if (File.Exists(path))
        {
            SaveFile save = SaveSystem.LoadSaveFile();
            plr.music = save.music;
            plr.soundeffects = save.soundeffects;
            plr.highscore = save.highscore;
        } else
        {
            SaveSystem.Save(plr);
        }
        int hours = Mathf.FloorToInt(plr.highscore / 3600);
        int minutes = Mathf.FloorToInt((plr.highscore - hours * 3600) / 60);
        int seconds = Mathf.FloorToInt(plr.highscore % 60);
        string timestring = string.Format("Highscore: " + hours.ToString() + ":{0:00}:{1:00}", minutes, seconds);
        highscoredisplay.GetComponent<TextMesh>().text = timestring;
        selected = 0;
        currentselections = selections;
        foreach (GameObject selection in selections)
        {
            selection.SetActive(true);
        }
        foreach (GameObject option in options)
        {
            option.SetActive(false);
        }
        if (plr.music == true)
        {
            options[0].GetComponent<TextMesh>().text = "MUSIC - ON";
        }
        else
        {
            options[0].GetComponent<TextMesh>().text = "MUSIC - OFF";
        }
        if (plr.soundeffects == true)
        {
            options[1].GetComponent<TextMesh>().text = "SOUND EFFECTS - ON";
        }
        else
        {
            options[1].GetComponent<TextMesh>().text = "SOUND EFFECTS - OFF";
        }
    }

    void Update()
    {
        foreach (GameObject selection in currentselections)
        {
            if (selection == currentselections[selected])
            {
                selection.GetComponent<TextMesh>().color = new Color(184f / 255f, 255f / 255f, 193f / 255f);
                selection.GetComponent<TextMesh>().fontStyle = FontStyle.Bold;
            } else
            {
                selection.GetComponent<TextMesh>().color = new Color(0f / 255f, 179f / 255f, 24f / 255f);
                selection.GetComponent<TextMesh>().fontStyle = FontStyle.Normal;
            }
        }
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
        {
            GameObject sound = Instantiate(changesound);
            sound.SetActive(true);
            selected = selected - 1;
            if (selected < 0)
            {
                selected = currentselections.Count - 1;
            }
        }
        if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S))
        {
            GameObject sound = Instantiate(changesound);
            sound.SetActive(true);
            selected = selected + 1;
            if (selected > currentselections.Count - 1)
            {
                selected = 0;
            }
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject sound = Instantiate(selectedsound);
            sound.SetActive(true);
            if (currentselections[selected].name == "PLAY")
            {
                SceneManager.LoadScene("Game",LoadSceneMode.Single);
            }
            if (currentselections[selected].name == "TUTORIAL")
            {
                SceneManager.LoadScene("Tutorial", LoadSceneMode.Single);
            }
            if (currentselections[selected].name == "MUSIC")
            {
                if (plr.music == true)
                {
                    plr.music = false;
                    currentselections[selected].GetComponent<TextMesh>().text = "MUSIC - OFF";
                }
                else
                {
                    plr.music = true;
                    currentselections[selected].GetComponent<TextMesh>().text = "MUSIC - ON";
                }
                SaveSystem.Save(plr);
            }
            if (currentselections[selected].name == "SOUND EFFECTS")
            {
                if (plr.soundeffects == true)
                {
                    plr.soundeffects = false;
                    currentselections[selected].GetComponent<TextMesh>().text = "SOUND EFFECTS - OFF";
                }
                else
                {
                    plr.soundeffects = true;
                    currentselections[selected].GetComponent<TextMesh>().text = "SOUND EFFECTS - ON";
                }
                SaveSystem.Save(plr);
            }
            if (currentselections[selected].name == "OPTIONS")
            {
                selected = 0;
                currentselections = options;
                foreach (GameObject selection in selections)
                {
                    selection.SetActive(false);
                }
                foreach (GameObject option in options)
                {
                    option.SetActive(true);
                }
            }
            if (currentselections[selected].name == "QUIT")
            {
                SaveSystem.Save(plr);
                Application.Quit();
            }
            if (currentselections[selected].name == "BACK")
            {
                selected = 0;
                currentselections = selections;
                foreach (GameObject selection in selections)
                {
                    selection.SetActive(true);
                }
                foreach (GameObject option in options)
                {
                    option.SetActive(false);
                }
            }
        }
    }
}
