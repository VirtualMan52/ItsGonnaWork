﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicScript : MonoBehaviour
{
    public Player plr;

    void Update()
    {
        if (plr.music == true)
        {
            gameObject.GetComponent<AudioSource>().volume = 0.75f;
        } else
        {
            gameObject.GetComponent<AudioSource>().volume = 0f;
        }
    }
}
